/** document me */
const GREEN = 1,
      RED   = 0;

/** document me */
var validate = function(){};

var i,
    /** document me */
    results;