/** @deprecated
*/
function foo() {

}

/** @deprecated since version 2.0
*/
function bar() {

}