function setPosition(newP) {
    /** document me */
    this.position = newP; // sets global property
}
