/**
    A builder function for the Stick application;
    @var {function} Application
 */
var {Application} = require("stick");