'use strict';

/** @exports module:my/shirt */
var myShirt = exports;
