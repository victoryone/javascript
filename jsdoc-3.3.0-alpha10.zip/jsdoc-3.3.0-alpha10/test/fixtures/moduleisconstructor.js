/**
   Describe the module here.
   @module mymodule/config
*/

/**
    Create a new configuration.
    
    @classdesc Describe the class here.
    @class
    @alias module:mymodule/config
    @param {string} id
*/
function Config(id) {
   /** Document me. */
   this.id = id;
}

module.exports = Config;