/** @constructor
    @author Michael Mathews <micmath@gmail.com>
*/
function Thingy() {
}

/** @author John Doe <john.doe@gmail.com>
 * @author Jane Doe <jane.doe@gmail.com> */
function Thingy2() {
}
