/**
    Describe your constructor function here.
    @class Describe your class here.
    @constructor
    @param {string} url
    @throws MalformedURL
 */
function Feed(url) {
}

/**
    Document your method here.
*/
Feed.prototype.refresh = function() {
}
