(function() {

    /** @alias <global>.log */
    var log = function() {
    }

})();
