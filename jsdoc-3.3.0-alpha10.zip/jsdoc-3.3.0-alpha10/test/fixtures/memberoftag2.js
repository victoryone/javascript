create(
    'Observable',
    {
        /** @memberof Observable */
        cache: [],

        /** @memberof Observable.prototype */
        publish: function(msg) {}
    }
);